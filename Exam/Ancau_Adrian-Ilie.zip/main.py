from ui import *

ui = UI()

ui.startup()